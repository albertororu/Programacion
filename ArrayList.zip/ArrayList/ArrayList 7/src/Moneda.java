public class Moneda {
    private int valor;
    private String posicion;

    public Moneda(int valor, String posicion) {
        this.valor = valor;
        this.posicion = posicion;
    }

    public int getValor() {
        return valor;
    }

    public String getPosicion() {
        return posicion;
    }

    public String toString() {
        return "Moneda generada: " + valor + " céntimos, " + posicion;
    }
}
