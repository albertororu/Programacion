import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Eurocoin {
    public static void main(String[] args) {
        List<Moneda> monedasGeneradas = new ArrayList<>();
        Moneda monedaAnterior = null;

        for (int i = 0; i < 6; i++) {
            Moneda monedaGenerada = generarMoneda(monedaAnterior);
            monedasGeneradas.add(monedaGenerada);
            monedaAnterior = monedaGenerada;
            System.out.println(monedaGenerada.toString());
        }
    }

    public static Moneda generarMoneda(Moneda monedaAnterior) {
        Random random = new Random();
        int valor;
        String posicion;

        if (monedaAnterior == null) {
            // Si es la primera moneda generada, el valor y la posición son aleatorios
            valor = random.nextInt(8);
            posicion = random.nextBoolean() ? "cara" : "cruz";
        } else {
            // Sino, el valor debe coincidir con la moneda anterior - 1, o ser igual a su valor
            int valorAnterior = monedaAnterior.getValor();
            valor = random.nextInt(2) == 0 ? valorAnterior : valorAnterior - 1;

            // La posición también puede coincidir con la moneda anterior
            posicion = random.nextInt(2) == 0 ? monedaAnterior.getPosicion() :
                    (monedaAnterior.getPosicion().equals("cara") ? "cruz" : "cara");
        }

        return new Moneda(valor, posicion);
    }
}