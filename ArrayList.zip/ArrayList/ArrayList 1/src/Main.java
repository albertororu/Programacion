import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList <String> alumnos = new ArrayList<String>();
                alumnos.add("Alberto");
                alumnos.add("Nerea");
                alumnos.add("Manuel");
                alumnos.add("Hector");
                alumnos.add("Paco");
                alumnos.add("Juan");
                    System.out.println("Contenido de la lista: ");
                        for (String nombre : alumnos) {
                            System.out.println(nombre);
                        }
    }
}