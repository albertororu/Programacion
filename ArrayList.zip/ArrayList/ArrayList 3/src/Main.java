import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos = new Scanner(System.in);
        ArrayList<Integer> numeros = new ArrayList<Integer>();
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());
            numeros.add(datos.nextInt());

        System.out.println("\nNumeros en el orden original: ");
            for (int a : numeros){
                System.out.println(a);
            }
                Collections.sort(numeros);
                System.out.println("\nNumeros ordenados: ");
                    for (int a : numeros) {
                        System.out.println(a);
                    }
    }
}